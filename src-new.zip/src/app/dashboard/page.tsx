'use client'

import { signOut, useSession } from 'next-auth/react'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'

interface Activity {
  id: string
  type: string
  description: string
  date: string
  commissionFee: number
  amount: number
}

export default function DashboardPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [activities, setActivities] = useState<Activity[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === 'loading') return
    if (!session) {
      router.push('/sign-in')
      return
    }

    fetch('/api/activities')
      .then(res => res.json())
      .then(data => {
        setActivities(data)
        setLoading(false)
      })
  }, [status, session])

  if (loading || status === 'loading' || !activities) {
    return <div className="text-white p-8">Loading dashboard...</div>
  }

  // 1h chart interval
  const hourlyData = activities.reduce((acc: any[], curr: any) => {
    const hour = new Date(curr.date)
    hour.setMinutes(0, 0, 0)
    const hourKey = hour.toISOString()

    const existing = acc.find(d => d.hour === hourKey)
    if (existing) {
      existing.profitLoss += curr.profitLoss
    } else {
      acc.push({ hour: hourKey, profitLoss: curr.profitLoss })
    }

  // 1m chart interval
  // const minuteData = userData.activities.reduce((acc: any[], curr: any) => {
  //   const minute = new Date(curr.date)
  //   minute.setSeconds(0, 0)
  //   const minuteKey = minute.toISOString()
  
  //   const existing = acc.find(d => d.minute === minuteKey)
  //   if (existing) {
  //     existing.profitLoss += curr.profitLoss
  //   } else {
  //     acc.push({ minute: minuteKey, profitLoss: curr.profitLoss })
  //   }

    return acc
  }, [])


  return (
    <div>
      <div className="page-header">
        <img src="/images/nebula-dashboard-icon.png" loading="eager" alt="" className="dashboard-icon-desktop"/>
        <div className="mobile-menu-btn">
          <svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20.6882 20.3262L10.3343 20.3262" stroke="white" strokeWidth="2" strokeLinecap="round" />
            <path d="M20.6882 15.3262L10.3343 15.3262" stroke="white" strokeWidth="2" strokeLinecap="round" />
            <path d="M20.6882 10.3262L10.3343 10.3262" stroke="white" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </div>
        <div className="page-header-text">John Smith</div>
        <div className="breadcrumbs-slash">
          <svg width="7" height="14" viewBox="0 0 7 14" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5.03857 2.09277L1.96153 11.9074" stroke="#2F2F2F" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        </div>
        <div className="page-header-text">Portfolio</div>
        <img src="/images/Ellipse-123.svg" loading="lazy" width={28} height={28} alt="" className="ellipse-123"/>
        <img src="/images/nebula-dashboard-icon.png" loading="eager" alt="" className="dashboard-icon-mobile"/>
      </div>
      <div className="page-container">
        <div className="side-menu">
          <a href="/dashboard" className="menu-btn w--current">
            <div className="btn-icon"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M6.08146 12.4765V8.6394C6.08146 8.46981 6.01408 8.30711 5.89415 8.18721C5.77422 8.0673 5.61156 7.99989 5.44195 7.99989H2.8839C2.71429 7.99989 2.55163 8.0673 2.43169 8.18721C2.31176 8.30711 2.24438 8.46981 2.24438 8.6394V12.4765C2.24438 12.6461 2.31176 12.8088 2.43169 12.9287C2.55163 13.0486 2.71429 13.116 2.8839 13.116M6.08146 12.4765C6.08146 12.6461 6.01408 12.8088 5.89415 12.9287C5.77422 13.0486 5.61156 13.116 5.44195 13.116H2.8839M6.08146 12.4765C6.08146 12.6461 6.14884 12.8088 6.26877 12.9287C6.3887 13.0486 6.55136 13.116 6.72097 13.116H9.27903C9.44862 13.116 9.61132 13.0486 9.73122 12.9287C9.85113 12.8088 9.91854 12.6461 9.91854 12.4765M6.08146 12.4765V6.08135C6.08146 5.91174 6.14884 5.74908 6.26877 5.62915C6.3887 5.50922 6.55136 5.44184 6.72097 5.44184H9.27903C9.44862 5.44184 9.61132 5.50922 9.73122 5.62915C9.85113 5.74908 9.91854 5.91174 9.91854 6.08135V12.4765M2.8839 13.116H11.8371M9.91854 12.4765C9.91854 12.6461 9.98594 12.8088 10.1059 12.9287C10.2258 13.0486 10.3885 13.116 10.5581 13.116H13.1161C13.2857 13.116 13.4484 13.0486 13.5683 12.9287C13.6882 12.8088 13.7556 12.6461 13.7556 12.4765V3.5233C13.7556 3.35369 13.6882 3.19103 13.5683 3.0711C13.4484 2.95117 13.2857 2.88379 13.1161 2.88379H10.5581C10.3885 2.88379 10.2258 2.95117 10.1059 3.0711C9.98594 3.19103 9.91854 3.35369 9.91854 3.5233V12.4765Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"></path>
            </svg></div>
            <div>Portfolio</div>
          </a>
          <a href="/deposit" className="menu-btn">
            <div className="btn-icon"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M7.99988 10.741V5.25875M7.99988 10.741L5.94403 8.68519M7.99988 10.741L10.0558 8.68519M12.1116 3.88818C11.5716 3.34822 10.9306 2.91991 10.2251 2.62768C9.51962 2.33546 8.7635 2.18506 7.99988 2.18506C7.23627 2.18506 6.48013 2.33546 5.77465 2.62768C5.06916 2.91991 4.42814 3.34822 3.88818 3.88818C3.34822 4.42814 2.91991 5.06916 2.62768 5.77464C2.33546 6.48013 2.18506 7.23626 2.18506 7.99988C2.18506 8.76349 2.33546 9.51961 2.62768 10.2251C2.91991 10.9306 3.34822 11.5716 3.88818 12.1116C4.97867 13.2021 6.45769 13.8147 7.99988 13.8147C9.54203 13.8147 11.0211 13.2021 12.1116 12.1116C13.2021 11.0211 13.8147 9.54203 13.8147 7.99988C13.8147 6.45769 13.2021 4.97867 12.1116 3.88818Z" stroke="currentColor" strokeLinecap="round"></path>
            </svg></div>
            <div>Deposit</div>
          </a>
          <a href="/withdraw" className="menu-btn">
            <div className="btn-icon"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M7.99988 5.259V10.7413M7.99988 5.259L5.94403 7.31481M7.99988 5.259L10.0558 7.31481M12.1116 12.1118C11.5716 12.6518 10.9306 13.0801 10.2251 13.3723C9.51962 13.6645 8.7635 13.8149 7.99988 13.8149C7.23627 13.8149 6.48013 13.6645 5.77465 13.3723C5.06916 13.0801 4.42814 12.6518 3.88818 12.1118C3.34822 11.5719 2.91991 10.9308 2.62768 10.2254C2.33546 9.51987 2.18506 8.76374 2.18506 8.00012C2.18506 7.23651 2.33546 6.48039 2.62768 5.7749C2.91991 5.0694 3.34822 4.4284 3.88818 3.8884C4.97867 2.7979 6.45769 2.1853 7.99988 2.1853C9.54203 2.1853 11.0211 2.7979 12.1116 3.8884C13.2021 4.9789 13.8147 6.45797 13.8147 8.00012C13.8147 9.54231 13.2021 11.0213 12.1116 12.1118Z" stroke="currentColor" strokeLinecap="round"></path>
            </svg></div>
            <div>Withdraw</div>
          </a>
          <button className="menu-btn last" onClick={() => signOut({ callbackUrl: '/sign-in' })}>
            <div className="btn-icon">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M2.48657 9.09034L6.19078 4.84375M2.48657 9.08839L6.19077 13.335" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
                <path d="M2.48657 9.09041L8.31598 9.09041C11.1864 9.09041 13.5133 6.76348 13.5133 3.89307V3.89307" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
              </svg>
            </div>
            <div>Sign out</div>
          </button>
        </div>

        <div className="page-card">
          <div className="portfolio-balance-container">
            <div className="portfolio-balance">${activities.reduce((acc, curr) => acc + curr.amount, 0).toLocaleString()}</div>
            <div className="text-m-muted">Portfolio Balance</div>
          </div>

          <div className="chart-container">
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={hourlyData}>
                <defs>
                  <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#2dd4ad" stopOpacity={0.1} />
                    <stop offset="100%" stopColor="#2dd4ad" stopOpacity={0} />
                  </linearGradient>
                </defs>

                <Line
                  type="monotone"
                  dataKey="profitLoss"
                  stroke="#2dd4ad"
                  strokeWidth={1.5}
                  dot={false}
                  fillOpacity={1}
                  fill="url(#chartGradient)"
                  isAnimationActive={false}
                />

                <XAxis
                  dataKey="hour" // or "minute"
                  hide={true}
                />
                <YAxis
                  domain={['dataMin - 2', 'dataMax + 2']}
                  hide={true}
                />
                <Tooltip content={null} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="stats-card">
            <div className="stats-container">
              <div className="text-m-muted">Status</div>
              <div className="text-m capital">Active</div>
            </div>
            <div className="stats-divider" />
            <div className="stats-container">
              <div className="text-m-muted">All-Time Earnings</div>
              <div className="text-m profit">${activities.reduce((acc, curr) => acc + curr.amount, 0).toLocaleString()}</div>
            </div>
            <div className="stats-divider" />
            <div className="stats-container">
              <div className="text-m-muted">Est. Yield</div>
              <div className="text-m">{activities.reduce((acc, curr) => acc + curr.amount, 0) / activities.length}%</div>
            </div>
            <div className="stats-divider" />
            <div className="stats-container">
              <div className="text-m-muted">Max Risk</div>
              <div className="text-m">{activities.reduce((acc, curr) => acc + Math.abs(curr.amount), 0) / activities.length}%</div>
            </div>
            <div className="stats-divider" />
            <div className="stats-container">
              <div className="text-m-muted">Account Type</div>
              <div className="text-m">{activities.length > 0 ? activities[0].type : 'N/A'}</div>
            </div>
            <div className="stats-divider" />
            <div className="stats-container">
              <div className="text-m-muted">Created On</div>
              <div className="text-m">{activities.length > 0 ? new Date(activities[0].date).toLocaleDateString() : 'N/A'}</div>
            </div>
          </div>

          <div className="recent-activity">
            <div className="display-text-sm">Recent activity</div>

            <div className="recent-activity-heading">
              <div className="text-m-muted">Type</div>
              <div className="text-m-muted">Description</div>
              <div className="text-m-muted">Date</div>
              <div className="text-m-muted">Fee</div>
              <div className="text-m-muted text-align-right">Amount</div>
            </div>

            {activities.map((activity: any) => (
              <div
                className={`recent-activity-li ${activity === activities[activities.length - 1] ? 'last' : ''}`}
                key={activity.id}
              >
                <div className="text-m">{activity.type.charAt(0).toUpperCase() + activity.type.slice(1)}</div>
                <div className="text-m">{activity.description || '-'}</div>
                <div className="text-m">
                  {new Date(activity.date).toLocaleDateString(undefined, {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                  })}
                </div>
                <div className="text-m">- ${activity.commissionFee.toFixed(2)}</div>
                <div className="flex col-gap-12 align-y-center align-x-right">
                  <div className={`text-m ${activity.amount >= 0 ? 'profit' : 'loss'}`}>
                    {activity.amount >= 0 ? '+' : '-'} ${Math.abs(activity.amount).toFixed(2)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
