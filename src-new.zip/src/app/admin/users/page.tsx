'use client'

import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'

export default function AdminUsersPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [users, setUsers] = useState([])

  useEffect(() => {
    if (status === 'loading') return

    if (!session || session.user.role !== 'ADMIN') {
      router.push('/sign-in')
      return
    }

    fetch('/api/admin/users')
      .then(res => res.json())
      .then(setUsers)
  }, [status, session])

  return (
    <div className="page-container">
      <div className="page-card">
        <h1 className="text-white text-xl mb-4">Admin - Users</h1>
        <table className="text-m" style={{ width: '100%', color: 'white' }}>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Account Type</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user: any) => (
              <tr key={user.id}>
                <td>{user.firstName} {user.lastName}</td>
                <td>{user.email}</td>
                <td>{user.accountType}</td>
                <td>{user.status}</td>
                <td>
                  <button
                    className="btn-outlined"
                    onClick={() => router.push(`/admin/users/${user.id}`)}
                  >
                    Edit
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
