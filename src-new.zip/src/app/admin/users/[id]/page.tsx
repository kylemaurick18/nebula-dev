// src/app/admin/users/[id]/page.tsx
'use client'

import { useRouter, useParams } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { useEffect, useState } from 'react'

export default function EditUserPage() {
  const { id } = useParams()
  const router = useRouter()
  const { data: session, status } = useSession()

  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (status === 'loading') return
    if (!session || session.user.role !== 'ADMIN') {
      router.push('/sign-in')
      return
    }

    fetch(`/api/admin/users/${id}`)
      .then(res => res.json())
      .then(setUser)
      .finally(() => setLoading(false))
  }, [status, session, id])

  const handleChange = (e: any) => {
    const { name, value } = e.target
    setUser((prev: any) => ({ ...prev, [name]: value }))
  }

  const handleSave = async () => {
    setSaving(true)
    await fetch(`/api/admin/users/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(user),
    })
    setSaving(false)
    alert('User saved!')
  }

  if (loading) return <div className="text-white p-8">Loading user...</div>
  if (!user) return <div className="text-white p-8">User not found</div>

  return (
    <div className="page-container">
      <div className="page-card">
        <h1 className="text-white text-xl mb-4">Editing {user.firstName} {user.lastName}</h1>

        <div className="stats-card mb-4">
          <div className="stats-container">
            <div className="text-m-muted">First Name</div>
            <input className="form-input" name="firstName" value={user.firstName} onChange={handleChange} />
          </div>
          <div className="stats-container">
            <div className="text-m-muted">Last Name</div>
            <input className="form-input" name="lastName" value={user.lastName} onChange={handleChange} />
          </div>
          <div className="stats-container">
            <div className="text-m-muted">Email</div>
            <input className="form-input" name="email" value={user.email} onChange={handleChange} />
          </div>
          <div className="stats-container">
            <div className="text-m-muted">Mobile Number</div>
            <input className="form-input" name="mobileNumber" value={user.mobileNumber} onChange={handleChange} />
          </div>
        </div>

        <div className="stats-card mb-4">
          <div className="stats-container">
            <div className="text-m-muted">Portfolio Balance</div>
            <input className="form-input" name="portfolioBalance" type="number" value={user.portfolioBalance} onChange={handleChange} />
          </div>
          <div className="stats-container">
            <div className="text-m-muted">All-Time Earnings</div>
            <input className="form-input" name="allTimeEarnings" type="number" value={user.allTimeEarnings} onChange={handleChange} />
          </div>
          <div className="stats-container">
            <div className="text-m-muted">Estimated Yield (%)</div>
            <input className="form-input" name="estimatedYield" type="number" value={user.estimatedYield} onChange={handleChange} />
          </div>
          <div className="stats-container">
            <div className="text-m-muted">Max Risk Per Day (%)</div>
            <input className="form-input" name="maxRiskPerDay" type="number" value={user.maxRiskPerDay} onChange={handleChange} />
          </div>
        </div>

        <button className="btn-white mb-6" onClick={handleSave} disabled={saving}>
          {saving ? 'Saving...' : 'Save Changes'}
        </button>

        <h2 className="text-white text-lg mb-2">Activity</h2>
        <table className="text-m" style={{ width: '100%', color: 'white', marginBottom: '20px' }}>
          <thead>
            <tr>
              <th>Type</th>
              <th>Description</th>
              <th>Date</th>
              <th>Fee</th>
              <th>Amount</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {user.activities.map((a: any) => (
              <tr key={a.id}>
                <td>{a.type}</td>
                <td>{a.description}</td>
                <td>{new Date(a.date).toLocaleDateString()}</td>
                <td>{a.commissionFee}</td>
                <td className={a.amount >= 0 ? 'text-m profit' : 'text-m loss'}>
                  {a.amount >= 0 ? '+' : ''}{a.amount.toFixed(2)}
                </td>
                <td>
                  <button
                    onClick={async () => {
                      const confirmDelete = confirm(`Delete activity ${a.tradeId}?`)
                      if (!confirmDelete) return

                      const res = await fetch(`/api/admin/activities/${a.id}`, {
                        method: 'DELETE',
                      })

                      if (res.ok) {
                        location.reload()
                      } else {
                        alert('Error deleting activity')
                      }
                    }}
                    className="btn-grey"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <h2 className="text-white text-lg mb-2">Add Activity</h2>
        <form
          onSubmit={async (e) => {
            e.preventDefault()
            const formData = new FormData(e.target as HTMLFormElement)

            const res = await fetch(`/api/admin/users/${id}/activities`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                type: formData.get('type'),
                description: formData.get('description'),
                date: formData.get('date'),
                tradeId: formData.get('tradeId'),
                commissionFee: parseFloat(formData.get('commissionFee') as string),
                amount: parseFloat(formData.get('amount') as string),
              }),
            })

            if (res.ok) {
              location.reload()
            } else {
              alert('Error saving activity')
            }
          }}
        >
          <div className="stats-card mb-4">
            <div className="stats-container">
              <div className="text-m-muted">Type</div>
              <select className="form-input" name="type" required>
                <option value="earning">Earning</option>
                <option value="deposit">Deposit</option>
                <option value="withdrawal">Withdrawal</option>
              </select>
            </div>
            <div className="stats-container">
              <div className="text-m-muted">Description</div>
              <input className="form-input" name="description" placeholder="Description" required />
            </div>
            <div className="stats-container">
              <div className="text-m-muted">Date</div>
              <input className="form-input" name="date" type="datetime-local" required />
            </div>
            <div className="stats-container">
              <div className="text-m-muted">ID</div>
              <input className="form-input" name="tradeId" required />
            </div>
            <div className="stats-container">
              <div className="text-m-muted">Fee</div>
              <input className="form-input" name="commissionFee" type="number" step="0.01" required />
            </div>
            <div className="stats-container">
              <div className="text-m-muted">Amount</div>
              <input className="form-input" name="amount" type="number" step="0.01" required />
            </div>
          </div>
          <button className="btn-white" type="submit">Add Activity</button>
        </form>
      </div>
    </div>
  )
}
