export default function Home() {
  return (
    <iframe
      src="https://nebula-investments.framer.website/"
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100vw",
        height: "100vh",
        border: "none",
      }}
      title="Nebula Investments"
    />
  );
}
